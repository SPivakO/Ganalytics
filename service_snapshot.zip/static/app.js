// State
let state = {
    accounts: [],
    campaigns: [],
    reportData: [],
    sortColumn: 'cost',
    sortDirection: 'desc'
};

// DOM Elements - Reports Tab
const accountsContainer = document.getElementById('accounts-container');
const campaignsContainer = document.getElementById('campaigns-container');
const testDateInput = document.getElementById('test-date');
const startDateInput = document.getElementById('start-date');
const endDateInput = document.getElementById('end-date');
const loadBtn = document.getElementById('load-btn');
const downloadBtn = document.getElementById('download-btn');
const resultsPanel = document.getElementById('results-panel');
const resultsBody = document.getElementById('results-body');
const groupByCampaignCheckbox = document.getElementById('group-by-campaign');

// DOM Elements - Upload Tab
const uploadAccountsContainer = document.getElementById('upload-accounts-container');
const uploadCampaignsContainer = document.getElementById('upload-campaigns-container');
const adgroupNameInput = document.getElementById('adgroup-name');
const youtubeUrlsInput = document.getElementById('youtube-urls');
const adTextsPreview = document.getElementById('ad-texts-preview');
const uploadBtn = document.getElementById('upload-btn');
const uploadResults = document.getElementById('upload-results');
const uploadLog = document.getElementById('upload-log');

// Common Elements
const loadingOverlay = document.getElementById('loading-overlay');
const errorMessage = document.getElementById('error-message');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeDates();
    initializeTabs();
    loadAccounts();
    loadAdTexts();
    setupEventListeners();
});

function initializeDates() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    startDateInput.value = formatDate(firstDay);
    endDateInput.value = formatDate(lastDay);
}

function formatDate(date) {
    return date.toISOString().split('T')[0];
}

function initializeTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            
            // Update buttons
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Update content
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.getElementById(`${tabId}-tab`).classList.add('active');
        });
    });
}

function setupEventListeners() {
    // Reports Tab - Radio button toggle
    document.querySelectorAll('input[name="adgroup_type"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            testDateInput.disabled = e.target.value !== 'test';
            if (e.target.value === 'test') {
                testDateInput.focus();
            }
        });
    });
    
    // Reload campaigns when dates change
    startDateInput.addEventListener('change', onDateChange);
    endDateInput.addEventListener('change', onDateChange);

    // Load button
    loadBtn.addEventListener('click', loadReport);

    // Download button
    downloadBtn.addEventListener('click', downloadCSV);

    // Table sorting
    document.querySelectorAll('th.sortable').forEach(th => {
        th.addEventListener('click', () => {
            const column = th.dataset.sort;
            if (state.sortColumn === column) {
                state.sortDirection = state.sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                state.sortColumn = column;
                state.sortDirection = column === 'asset_name' || column === 'campaign' ? 'asc' : 'desc';
            }
            sortAndRenderTable();
            updateSortIndicators();
        });
    });

    // Upload button
    uploadBtn.addEventListener('click', createTestAdGroups);
}

// ==================== REPORTS TAB ====================

async function loadAccounts() {
    try {
        const response = await fetch('/api/accounts');
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to load accounts');
        }
        
        state.accounts = data.accounts;
        renderAccounts(accountsContainer, 'onAccountChange');
        renderAccounts(uploadAccountsContainer, 'onUploadAccountChange');
    } catch (error) {
        showError('Failed to load accounts: ' + error.message);
    }
}

function renderAccounts(container, onChangeHandler) {
    container.innerHTML = `
        <div class="select-actions">
            <button onclick="selectAll('${container.id}', true, ${onChangeHandler})">Select All</button>
            <button onclick="selectAll('${container.id}', false, ${onChangeHandler})">Deselect All</button>
        </div>
        <div class="checkbox-list">
            ${state.accounts.map(acc => `
                <label class="checkbox-item">
                    <input type="checkbox" value="${acc.id}" onchange="${onChangeHandler}()">
                    <span title="${acc.name}">${acc.name}</span>
                </label>
            `).join('')}
        </div>
    `;
}

function selectAll(containerId, select, onChangeHandler) {
    const container = document.getElementById(containerId);
    container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.checked = select;
    });
    if (onChangeHandler) onChangeHandler();
}

function selectAllAccounts(select) {
    selectAll('accounts-container', select, onAccountChange);
}

function onDateChange() {
    const selectedIds = getSelectedAccountIds();
    if (selectedIds.length > 0) {
        onAccountChange();
    }
}

async function onAccountChange() {
    const selectedIds = getSelectedAccountIds();
    
    if (selectedIds.length === 0) {
        campaignsContainer.innerHTML = '<div class="placeholder">Select accounts first</div>';
        state.campaigns = [];
        return;
    }
    
    const startDate = startDateInput.value;
    const endDate = endDateInput.value;
    
    if (!startDate || !endDate) {
        campaignsContainer.innerHTML = '<div class="placeholder">Select date range first</div>';
        return;
    }
    
    campaignsContainer.innerHTML = '<div class="loading">Loading campaigns with spend...</div>';
    
    try {
        const response = await fetch(`/api/campaigns?account_ids=${selectedIds.join(',')}&start_date=${startDate}&end_date=${endDate}`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to load campaigns');
        }
        
        state.campaigns = data.campaigns;
        renderCampaigns(campaignsContainer);
    } catch (error) {
        campaignsContainer.innerHTML = `<div class="placeholder">Error: ${error.message}</div>`;
    }
}

function renderCampaigns(container) {
    if (state.campaigns.length === 0) {
        container.innerHTML = '<div class="placeholder">No campaigns found</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="select-actions">
            <button onclick="selectAllCampaigns('${container.id}', true)">Select All</button>
            <button onclick="selectAllCampaigns('${container.id}', false)">Deselect All</button>
        </div>
        <div class="checkbox-list">
            ${state.campaigns.map(camp => `
                <label class="checkbox-item">
                    <input type="checkbox" value="${camp.id}" checked>
                    <span title="${camp.name}">${camp.name}</span>
                </label>
            `).join('')}
        </div>
    `;
}

function selectAllCampaigns(containerId, select) {
    const container = document.getElementById(containerId);
    container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.checked = select;
    });
}

function getSelectedAccountIds() {
    return Array.from(accountsContainer.querySelectorAll('input[type="checkbox"]:checked'))
        .map(cb => cb.value);
}

function getSelectedCampaignIds() {
    return Array.from(campaignsContainer.querySelectorAll('input[type="checkbox"]:checked'))
        .map(cb => cb.value);
}

async function loadReport() {
    const accountIds = getSelectedAccountIds();
    const campaignIds = getSelectedCampaignIds();
    const adgroupType = document.querySelector('input[name="adgroup_type"]:checked').value;
    const testDate = testDateInput.value;
    const startDate = startDateInput.value;
    const endDate = endDateInput.value;
    const groupByCampaign = groupByCampaignCheckbox.checked;
    
    if (accountIds.length === 0) {
        showError('Please select at least one account');
        return;
    }
    
    if (!startDate || !endDate) {
        showError('Please select date range');
        return;
    }
    
    if (adgroupType === 'test' && !testDate) {
        showError('Please enter test date (e.g. 181225)');
        return;
    }
    
    hideError();
    showLoading();
    
    try {
        const response = await fetch('/api/report', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                account_ids: accountIds,
                campaign_ids: campaignIds,
                adgroup_type: adgroupType,
                test_date: testDate,
                start_date: startDate,
                end_date: endDate,
                group_by_campaign: groupByCampaign
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to load report');
        }
        
        state.reportData = data.data;
        renderResults(data);
    } catch (error) {
        showError('Failed to load report: ' + error.message);
    } finally {
        hideLoading();
    }
}

function renderResults(data) {
    document.getElementById('results-count').textContent = `${data.count} creatives`;
    document.getElementById('total-cost').textContent = formatCurrency(data.totals.cost);
    document.getElementById('total-impressions').textContent = formatNumber(data.totals.impressions);
    document.getElementById('total-installs').textContent = formatNumber(data.totals.installs);
    
    resultsPanel.classList.remove('hidden');
    
    sortAndRenderTable();
    updateSortIndicators();
}

function sortAndRenderTable() {
    const sorted = [...state.reportData].sort((a, b) => {
        let aVal = a[state.sortColumn];
        let bVal = b[state.sortColumn];
        
        if (typeof aVal === 'string') {
            aVal = aVal.toLowerCase();
            bVal = bVal.toLowerCase();
        }
        
        if (state.sortDirection === 'asc') {
            return aVal > bVal ? 1 : -1;
        } else {
            return aVal < bVal ? 1 : -1;
        }
    });
    
    resultsBody.innerHTML = sorted.map(row => `
        <tr>
            <td class="asset-name" title="${escapeHtml(row.asset_name)}">${escapeHtml(row.asset_name)}</td>
            <td class="campaign-name" title="${escapeHtml(row.campaign)}">${escapeHtml(row.campaign)}</td>
            <td class="numeric cost-cell">${formatCurrency(row.cost)}</td>
            <td class="numeric impressions-cell">${formatNumber(row.impressions)}</td>
            <td class="numeric installs-cell">${formatNumber(row.installs)}</td>
        </tr>
    `).join('');
}

function updateSortIndicators() {
    document.querySelectorAll('th.sortable').forEach(th => {
        th.classList.remove('sorted-asc', 'sorted-desc');
        if (th.dataset.sort === state.sortColumn) {
            th.classList.add(state.sortDirection === 'asc' ? 'sorted-asc' : 'sorted-desc');
        }
    });
}

function downloadCSV() {
    if (state.reportData.length === 0) return;
    
    const headers = ['asset_name', 'campaign', 'cost', 'impressions', 'installs'];
    const csvContent = [
        headers.join(','),
        ...state.reportData.map(row => 
            headers.map(h => {
                let val = row[h];
                if (typeof val === 'string') {
                    val = `"${val.replace(/"/g, '""')}"`;
                }
                return val;
            }).join(',')
        )
    ].join('\n');
    
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `youtube_assets_${startDateInput.value}_${endDateInput.value}.csv`;
    link.click();
    URL.revokeObjectURL(url);
}

// ==================== UPLOAD TAB ====================

async function loadAdTexts() {
    try {
        const response = await fetch('/api/ad-texts');
        const data = await response.json();
        
        adTextsPreview.innerHTML = `
            <h4>Headlines</h4>
            <ul>
                ${data.headlines.map(h => `<li>${escapeHtml(h)}</li>`).join('')}
            </ul>
            <h4>Descriptions</h4>
            <ul>
                ${data.descriptions.map(d => `<li>${escapeHtml(d)}</li>`).join('')}
            </ul>
        `;
    } catch (error) {
        adTextsPreview.innerHTML = '<div class="placeholder">Failed to load ad texts</div>';
    }
}

async function onUploadAccountChange() {
    const selectedIds = getUploadSelectedAccountIds();
    
    if (selectedIds.length === 0) {
        uploadCampaignsContainer.innerHTML = '<div class="placeholder">Select accounts first</div>';
        return;
    }
    
    uploadCampaignsContainer.innerHTML = '<div class="loading">Loading campaigns...</div>';
    
    try {
        const response = await fetch(`/api/all-campaigns?account_ids=${selectedIds.join(',')}`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to load campaigns');
        }
        
        renderUploadCampaigns(data.campaigns);
    } catch (error) {
        uploadCampaignsContainer.innerHTML = `<div class="placeholder">Error: ${error.message}</div>`;
    }
}

function renderUploadCampaigns(campaigns) {
    if (campaigns.length === 0) {
        uploadCampaignsContainer.innerHTML = '<div class="placeholder">No campaigns found</div>';
        return;
    }
    
    uploadCampaignsContainer.innerHTML = `
        <div class="select-actions">
            <button onclick="selectAllCampaigns('upload-campaigns-container', true)">Select All</button>
            <button onclick="selectAllCampaigns('upload-campaigns-container', false)">Deselect All</button>
        </div>
        <div class="checkbox-list">
            ${campaigns.map(camp => `
                <label class="checkbox-item">
                    <input type="checkbox" value="${camp.id}">
                    <span title="${camp.name}">${camp.name}</span>
                </label>
            `).join('')}
        </div>
    `;
}

function getUploadSelectedAccountIds() {
    return Array.from(uploadAccountsContainer.querySelectorAll('input[type="checkbox"]:checked'))
        .map(cb => cb.value);
}

function getUploadSelectedCampaignIds() {
    return Array.from(uploadCampaignsContainer.querySelectorAll('input[type="checkbox"]:checked'))
        .map(cb => cb.value);
}

async function createTestAdGroups() {
    const campaignIds = getUploadSelectedCampaignIds();
    const adgroupName = adgroupNameInput.value.trim();
    const youtubeUrls = youtubeUrlsInput.value.trim().split('\n').filter(url => url.trim());
    
    if (campaignIds.length === 0) {
        showError('Please select at least one campaign');
        return;
    }
    
    if (!adgroupName) {
        showError('Please enter ad group name');
        return;
    }
    
    if (youtubeUrls.length === 0) {
        showError('Please enter at least one YouTube URL');
        return;
    }
    
    hideError();
    showLoading();
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                campaign_ids: campaignIds,
                adgroup_name: adgroupName,
                youtube_urls: youtubeUrls
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to create ad groups');
        }
        
        renderUploadResults(data.results);
    } catch (error) {
        showError('Failed to create ad groups: ' + error.message);
    } finally {
        hideLoading();
    }
}

function renderUploadResults(results) {
    uploadResults.classList.remove('hidden');
    
    uploadLog.innerHTML = results.map(r => {
        const logsHtml = r.logs ? `<div class="upload-logs">${r.logs.map(l => `<div class="log-line">${escapeHtml(l)}</div>`).join('')}</div>` : '';
        
        if (r.success) {
            return `
                <div class="upload-log-item success">
                    <div class="log-header">
                        ✓ Created ad group "<strong>${escapeHtml(r.adgroup_name)}</strong>" 
                        with ${r.videos_count} videos (${r.assets_created || 0} new assets)
                        <span class="campaign-name">(Campaign ID: ${r.campaign_id})</span>
                    </div>
                    ${logsHtml}
                </div>
            `;
        } else {
            return `
                <div class="upload-log-item error">
                    <div class="log-header">
                        ✗ Failed for campaign ${r.campaign_id}: ${escapeHtml(r.error)}
                    </div>
                    ${logsHtml}
                </div>
            `;
        }
    }).join('');
}

// ==================== HELPERS ====================

function formatCurrency(value) {
    return '$' + value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatNumber(value) {
    return value.toLocaleString('en-US');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showLoading() {
    loadingOverlay.classList.remove('hidden');
    loadBtn.disabled = true;
    uploadBtn.disabled = true;
}

function hideLoading() {
    loadingOverlay.classList.add('hidden');
    loadBtn.disabled = false;
    uploadBtn.disabled = false;
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
}

function hideError() {
    errorMessage.classList.add('hidden');
}

